"""
Sanity tests for the closed-form Black-Scholes reference.

We don't test that bs_price is monotone in vol or that max() returns a
maximum — those are properties of the math, not the code.  We test the
*one* non-trivial identity it should satisfy (put-call parity) on a few
diverse parameter sets, plus the input validation branch.
"""

import math

import pytest

from src.core import bs_price


@pytest.mark.parametrize("S,K,T,r,sigma", [
    (100, 100, 1.0, 0.05, 0.20),    # ATM, baseline
    (80, 100, 0.5, 0.03, 0.30),     # OTM call / ITM put
    (120, 100, 2.0, 0.07, 0.15),    # ITM call, long-dated
    (100, 110, 0.25, 0.00, 0.25),   # zero rate, short-dated
])
def test_put_call_parity(S, K, T, r, sigma):
    """C - P = S - K e^{-rT} is a pure no-arbitrage identity.

    Failing this means signs, discounting, or one of the d1/d2 branches
    is wrong — and the failing parameter set will tell you which.
    """
    C = bs_price(S, K, T, r, sigma, "call")
    P = bs_price(S, K, T, r, sigma, "put")
    assert C - P == pytest.approx(S - K * math.exp(-r * T), abs=1e-10)


def test_invalid_option_type_raises():
    with pytest.raises(ValueError, match="option_type"):
        bs_price(100, 100, 1.0, 0.05, 0.2, "banana")
