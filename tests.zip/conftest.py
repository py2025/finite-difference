"""Shared fixtures used across the test suite."""

import pytest


@pytest.fixture
def atm():
    """Vanilla at-the-money parameters used in most tests."""
    return dict(S0=100.0, K=100.0, T=1.0, r=0.05, sigma=0.20)


@pytest.fixture
def sabr_params():
    """A typical SABR parameter set."""
    return dict(alpha=0.20, beta=1.0, rho=-0.3, nu=0.4)
